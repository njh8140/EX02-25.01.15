package kr.hkit.sample;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import kr.hkit.domain.BoardVO;
import kr.hkit.domain.Criteria;
//import kr.hkit.domain.BoardVO;
import kr.hkit.mapper.BoardMapper;
import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class DBtest {

	@Setter(onMethod_ = @Autowired)
	private BoardMapper mapper;
	
	//@Test //insert
	public void testInsert() {
		BoardVO board = new BoardVO();
		board.setTitle("spring");
		board.setContent("java");
		board.setWriter("nam");
		
		mapper.insert(board);
		
		log.info(board);
	}
	
	//@Test //
	public void BoardTest() {
		mapper.getList().forEach(board->log.info("@@ " + board));
		
		//for(BoardVO board : mapper.getList())
		
		//log.info(board);
		
	}
	
	//@Test //select insert
	public void testInsetSelectKey() {
		BoardVO board = new BoardVO();
		board.setTitle("web");
		board.setContent("java");
		board.setWriter("code");
		
		mapper.insertSelectKey(board);
		log.info(board);
		
	}
	
	//@Test // select where
	public void testRead() {
		BoardVO board =mapper.read(1L);
		log.info("0000"+board);
	}
	
	//@Test
	public void testDelete() {
		mapper.delete(10L);
		//int board =mapper.delete(11L);
		//log.info(board);
		log.info("삭제완료 : " + mapper.delete(10L));
	} 
	
	//@Test //update
	public void testUpdate() {
		BoardVO board = new BoardVO();
		board.setBno(7L);
		board.setTitle("TOBY");
		board.setContent("SPRING");
		board.setWriter("Lee");
		
		mapper.update(board); 
		
		log.info("수정 완료 : " + mapper.update(board));
	}
	
	//@Test //paging
	public void testPaging() {
		Criteria cri = new Criteria(2, 20);
		mapper.getListWithPaging(cri).forEach(board-> log.info("!!!!" + board));
	}
	
	@Test
	public void testGetTotal() {
		Criteria cri = new Criteria();
		
		cri.setType("W");
		cri.setKeyword("Lee");
		
		//log.info("(db갯수)total : "+mapper.getTotal(new Criteria())); // 전체 db 수
		log.info("(db갯수)total : "+mapper.getTotal(cri)); // 조건부 검색
	}
	
	//@Test
	public void testSearch() {
		Criteria cri = new Criteria();
		
		cri.setType("W");
		cri.setKeyword("Lee");
		
		mapper.getListWithPaging(cri).forEach(board->log.info(board));
		
	}
}