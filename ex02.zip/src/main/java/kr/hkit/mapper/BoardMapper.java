package kr.hkit.mapper;

import java.util.List;

//import org.apache.ibatis.annotations.Select;

import kr.hkit.domain.BoardVO;
import kr.hkit.domain.Criteria;

public interface BoardMapper {
	
	//@Select("select * from tbl_board")
	public List<BoardVO> getList();

	public List<BoardVO> getListWithPaging(Criteria cri); // 페이징
	
	public void insert(BoardVO board); // 등록
	
	public void insertSelectKey(BoardVO board);
	
	public BoardVO read(long bno); //조건부 찾기

	public int delete(long bno); //조건부 삭제
	
	public int update(BoardVO board); //업데이트
	
	public int getTotal(Criteria cri);

}
